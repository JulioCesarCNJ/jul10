/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.campeonato.facade;

import br.com.campeonato.dao.JogoDAO;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author julio.cesar
 */
@Stateless
public class JogoDAOFacade extends AbstractFacade<JogoDAO> {

    @PersistenceContext(unitName = "CampeonatoPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public JogoDAOFacade() {
        super(JogoDAO.class);
    }
    
}
