/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.campeonato.dao;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author julio.cesar
 */
@Entity
@Table(name = "time")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TimeDAO.findAll", query = "SELECT t FROM TimeDAO t")
    , @NamedQuery(name = "TimeDAO.findByIdTime", query = "SELECT t FROM TimeDAO t WHERE t.idTime = :idTime")
    , @NamedQuery(name = "TimeDAO.findByNmTime", query = "SELECT t FROM TimeDAO t WHERE t.nmTime = :nmTime")
    , @NamedQuery(name = "TimeDAO.findByPontos", query = "SELECT t FROM TimeDAO t WHERE t.pontos = :pontos")
    , @NamedQuery(name = "TimeDAO.findByGolspro", query = "SELECT t FROM TimeDAO t WHERE t.golspro = :golspro")
    , @NamedQuery(name = "TimeDAO.findByGolscontra", query = "SELECT t FROM TimeDAO t WHERE t.golscontra = :golscontra")
    , @NamedQuery(name = "TimeDAO.findBySaldogols", query = "SELECT t FROM TimeDAO t WHERE t.saldogols = :saldogols")
    , @NamedQuery(name = "TimeDAO.findByVitoria", query = "SELECT t FROM TimeDAO t WHERE t.vitoria = :vitoria")
    , @NamedQuery(name = "TimeDAO.findByDerrota", query = "SELECT t FROM TimeDAO t WHERE t.derrota = :derrota")})
public class TimeDAO implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    private Integer idTime;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    private String nmTime;
    private Integer pontos;
    private Integer golspro;
    private Integer golscontra;
    private Integer saldogols;
    private Integer vitoria;
    private Integer derrota;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idtime1")
    private Collection<JogoDAO> jogoDAOCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idtime2")
    private Collection<JogoDAO> jogoDAOCollection1;

    public TimeDAO() {
    }

    public TimeDAO(Integer idTime) {
        this.idTime = idTime;
    }

    public TimeDAO(Integer idTime, String nmTime) {
        this.idTime = idTime;
        this.nmTime = nmTime;
    }

    public Integer getIdTime() {
        return idTime;
    }

    public void setIdTime(Integer idTime) {
        this.idTime = idTime;
    }

    public String getNmTime() {
        return nmTime;
    }

    public void setNmTime(String nmTime) {
        this.nmTime = nmTime;
    }

    public Integer getPontos() {
        return pontos;
    }

    public void setPontos(Integer pontos) {
        this.pontos = pontos;
    }

    public Integer getGolspro() {
        return golspro;
    }

    public void setGolspro(Integer golspro) {
        this.golspro = golspro;
    }

    public Integer getGolscontra() {
        return golscontra;
    }

    public void setGolscontra(Integer golscontra) {
        this.golscontra = golscontra;
    }

    public Integer getSaldogols() {
        return saldogols;
    }

    public void setSaldogols(Integer saldogols) {
        this.saldogols = saldogols;
    }

    public Integer getVitoria() {
        return vitoria;
    }

    public void setVitoria(Integer vitoria) {
        this.vitoria = vitoria;
    }

    public Integer getDerrota() {
        return derrota;
    }

    public void setDerrota(Integer derrota) {
        this.derrota = derrota;
    }

    @XmlTransient
    public Collection<JogoDAO> getJogoDAOCollection() {
        return jogoDAOCollection;
    }

    public void setJogoDAOCollection(Collection<JogoDAO> jogoDAOCollection) {
        this.jogoDAOCollection = jogoDAOCollection;
    }

    @XmlTransient
    public Collection<JogoDAO> getJogoDAOCollection1() {
        return jogoDAOCollection1;
    }

    public void setJogoDAOCollection1(Collection<JogoDAO> jogoDAOCollection1) {
        this.jogoDAOCollection1 = jogoDAOCollection1;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idTime != null ? idTime.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TimeDAO)) {
            return false;
        }
        TimeDAO other = (TimeDAO) object;
        if ((this.idTime == null && other.idTime != null) || (this.idTime != null && !this.idTime.equals(other.idTime))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "" + nmTime + " ";
    }
    
}
