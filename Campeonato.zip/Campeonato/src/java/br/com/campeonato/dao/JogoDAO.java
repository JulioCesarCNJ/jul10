/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.campeonato.dao;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author julio.cesar
 */
@Entity
@Table(name = "jogo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "JogoDAO.findAll", query = "SELECT j FROM JogoDAO j")
    , @NamedQuery(name = "JogoDAO.findByIdjogo", query = "SELECT j FROM JogoDAO j WHERE j.idjogo = :idjogo")
    , @NamedQuery(name = "JogoDAO.findByTime1placar", query = "SELECT j FROM JogoDAO j WHERE j.time1placar = :time1placar")
    , @NamedQuery(name = "JogoDAO.findByTime2placar", query = "SELECT j FROM JogoDAO j WHERE j.time2placar = :time2placar")})
public class JogoDAO implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    private Integer idjogo;
    @Basic(optional = false)
    @NotNull
    private int time1placar;
    @Basic(optional = false)
    @NotNull
    private int time2placar;
    @JoinColumn(name = "idrodada", referencedColumnName = "idrodada")
    @ManyToOne(optional = false)
    private RodadaDAO idrodada;
    @JoinColumn(name = "idtime1", referencedColumnName = "idTime")
    @ManyToOne(optional = false)
    private TimeDAO idtime1;
    @JoinColumn(name = "idtime2", referencedColumnName = "idTime")
    @ManyToOne(optional = false)
    private TimeDAO idtime2;

    public JogoDAO() {
    }

    public JogoDAO(Integer idjogo) {
        this.idjogo = idjogo;
    }

    public JogoDAO(Integer idjogo, int time1placar, int time2placar) {
        this.idjogo = idjogo;
        this.time1placar = time1placar;
        this.time2placar = time2placar;
    }

    public Integer getIdjogo() {
        return idjogo;
    }

    public void setIdjogo(Integer idjogo) {
        this.idjogo = idjogo;
    }

    public int getTime1placar() {
        return time1placar;
    }

    public void setTime1placar(int time1placar) {
        this.time1placar = time1placar;
    }

    public int getTime2placar() {
        return time2placar;
    }

    public void setTime2placar(int time2placar) {
        this.time2placar = time2placar;
    }

    public RodadaDAO getIdrodada() {
        return idrodada;
    }

    public void setIdrodada(RodadaDAO idrodada) {
        this.idrodada = idrodada;
    }

    public TimeDAO getIdtime1() {
        return idtime1;
    }

    public void setIdtime1(TimeDAO idtime1) {
        this.idtime1 = idtime1;
    }

    public TimeDAO getIdtime2() {
        return idtime2;
    }

    public void setIdtime2(TimeDAO idtime2) {
        this.idtime2 = idtime2;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idjogo != null ? idjogo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof JogoDAO)) {
            return false;
        }
        JogoDAO other = (JogoDAO) object;
        if ((this.idjogo == null && other.idjogo != null) || (this.idjogo != null && !this.idjogo.equals(other.idjogo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "" + idjogo + " ";
    }
    
}
